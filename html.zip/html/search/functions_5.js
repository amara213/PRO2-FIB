var searchData=
[
  ['hacer_5fviaje_129',['hacer_viaje',['../classCuenca.html#a5567d61fc29a6fa40b5e0edb542aa1c3',1,'Cuenca']]]
];
