var searchData=
[
  ['inventarios_156',['inventarios',['../classCuenca.html#a27de5669765002e855dc73f2c7933bd9',1,'Cuenca']]]
];
