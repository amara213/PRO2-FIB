var searchData=
[
  ['setpeso_68',['setPeso',['../classProducto.html#a93816d8ae0ea3ac9b6899717ccc6b223',1,'Producto']]],
  ['setvolumen_69',['setVolumen',['../classProducto.html#a4169d872b39b0c7767965834ca5ea812',1,'Producto']]]
];
