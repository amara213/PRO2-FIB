var searchData=
[
  ['redistribuir_65',['redistribuir',['../classCuenca.html#a544e89188047f2dff26246a9af671858',1,'Cuenca']]],
  ['redistribuirrecursi_66',['redistribuirRecursi',['../classCuenca.html#a6d25fd4211fb8b6cfe1d4ced36d0db5f',1,'Cuenca']]],
  ['reiniciar_5fbarco_67',['reiniciar_barco',['../classBarco.html#abe7d10045cd11e8e7983041dac9a10be',1,'Barco']]]
];
