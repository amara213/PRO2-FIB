var searchData=
[
  ['tiene_5fneces_182',['tiene_neces',['../classCiudad.html#ac63aa6e91f5ac6a8df02c03f1eccd74c',1,'Ciudad']]],
  ['totales_183',['totales',['../classCiudad.html#af560863fd54a1bd9c281e1565c4f9953',1,'Ciudad']]]
];
