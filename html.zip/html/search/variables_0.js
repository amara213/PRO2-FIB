var searchData=
[
  ['ciudades_154',['ciudades',['../classCuenca.html#a8c96596c804c461ba75968dbdf138490',1,'Cuenca']]],
  ['comprar_155',['comprar',['../classBarco.html#a2dd4ef30e47e90a4a48c493854137589',1,'Barco']]]
];
